 Supported Target | ESP32 |
| ---------------- | ----- |

# NicE Bouy

ToDo
calculations of speed depending of angle to stear and distance
Light indicators for viewing speed of engine
Home button for storing GPS postition
Log data trough lora
Entering anchor point troug Lora
Remote stearing trough lora
setting anchor point troug Lora


### Hardware Required

* GPS 6900 baud
* Compas 303L
* 2 ESC
* Lora 433MHz

### Build and Flash

Before compiling for the first time the following steps has te be done.
if presend
remove the .vscode dir.
remove managed_components dir

Commit to git.hub