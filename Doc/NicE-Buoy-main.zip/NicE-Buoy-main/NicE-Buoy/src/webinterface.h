#ifndef WEBINTERFACE_H_
#define WEBINTERFACE_H_

extern int notify;
void websetup(void);
void webloop(void);

#endif /* WEBINTERFACE_H_ */
