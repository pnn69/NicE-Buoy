#ifndef LORA_H_
#define LORA_H_
#include "Arduino.h"

/*
    MSG_ID (127 msg possible)
    [Designator][Reciever][MSG_ID][lengt_msg][msg][rssi_reciever][snr_reciever]
    msb msg_ID is answer or request. 1 means request. zerro answer from divice
    rssi and snr are 1 and -1 at request (No rssi known)

*/

struct loraDataType
{
    byte destination;
    byte sender;
    int recipient;
    byte id;
    byte status;
    byte messagelength;
    String message;
    int rssi;
    float snr;
};

extern loraDataType loraIn;
extern loraDataType loraOut;

extern bool loraOK;
bool InitLora(void);
void sendLora(void);
int polLora(void);

#endif /* LORA_H_ */
