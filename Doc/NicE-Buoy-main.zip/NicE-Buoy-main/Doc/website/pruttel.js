console.log("running javascript")
console.log(1 + 2)
