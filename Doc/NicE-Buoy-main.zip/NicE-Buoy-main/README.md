# NicE-Buoy
This device sails autonome to a given location.
