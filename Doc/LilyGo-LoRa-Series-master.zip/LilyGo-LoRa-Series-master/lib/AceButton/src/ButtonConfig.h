/*
 * This file has moved to <ace_button/ButtonConfig.h> and is deprecated as
 * of version 1.1. The <AceButton.h> header automatically includes
 * <ace_button/ButtonConfig.h>. You can remove the line in your code that does:
 *
 *  #include <ButtonConfig.h>
 *
 * You only need to do:
 *
 *  #include <AceButton.h>
 */
