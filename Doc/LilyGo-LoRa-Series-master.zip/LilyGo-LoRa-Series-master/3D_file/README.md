
## This is 3D .STP file
